#!/bin/bash

# Generate the file table-case-studies.txt.
if [ "x${JAVA_HOME}" = "x" ]; then
  has_java_home="no"
else
  has_java_home="yes"
fi

if [ "${has_java_home}" = "no" ]; then
    echo "JAVA_HOME is not set to a JAVA 8"
    exit 1
fi

if [ "${has_java_home}" = "yes" ]; then
    java_version=$("${JAVA_HOME}"/bin/java -version 2>&1 | head -1 | cut -d'"' -f2 | sed '/^1\./s///' | cut -d'.' -f1)
    if [ "${java_version}" != 8 ]; then
        echo "JAVA_HOME is not set to a JAVA 8"
        exit 1
    fi  
fi

set -o nounset
# set -o pipefail
# Display commands and their arguments as they are executed.
set -x
# set -v : Display shell input lines as they are read.

scratch=$2
mkdir -p "$scratch"

export CHECKERFRAMEWORK=$1

# Runs DTC on Deflaker benchmark - Checkstyle.
# Arguments:
#  * project name
#  * git repository
#  * branch name
runDTC () {
  project=$1
  gitrepo=$2
  gitbranch=$3

  reponame=${gitrepo##*/}
  echo "reponame=$reponame"
  dirbasename=$reponame-branch-$gitbranch
  dir=$scratch/$dirbasename
  echo "dir=$dir"

  if [ -d "$dir" ] ; then
      echo "$dir exists"
      git -C "$dir" pull
  else
      echo "$dir does not exist"
      (cd "$scratch" && git clone "$gitrepo" --branch "$gitbranch" "$dirbasename")
  fi

  typecheck_command="mvn clean compile"

  (cd "$dir" && $typecheck_command > dtc-output.txt 2>&1)
}


# Arguments are: project gitrepo gitbranch

runDTC "checkstyle" "https://github.com/t-rasmud/checkstyle" "artifact-eval-for-deflaker-bug"
