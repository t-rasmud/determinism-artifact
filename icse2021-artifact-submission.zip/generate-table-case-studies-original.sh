#!/bin/bash

# Generate the file table-case-studies.txt.
if [ "x${JAVA_HOME}" = "x" ]; then
  has_java_home="no"
else
  has_java_home="yes"
fi

if [ "${has_java_home}" = "no" ]; then
    echo "JAVA_HOME is not set to a JAVA 8"
    exit 1
fi

if [ "${has_java_home}" = "yes" ]; then
    java_version=$("${JAVA_HOME}"/bin/java -version 2>&1 | head -1 | cut -d'"' -f2 | sed '/^1\./s///' | cut -d'.' -f1)
    if [ "${java_version}" != 8 ]; then
        echo "JAVA_HOME is not set to a JAVA 8"
        exit 1
    fi  
fi

set -o nounset
# set -o pipefail
# Display commands and their arguments as they are executed.
set -x
# set -v : Display shell input lines as they are read.

scratch=$2
mkdir -p "$scratch"

rm -f table-case-studies-original.txt
echo "% This file is generated.  DO NOT EDIT!" > table-case-studies-original.txt
echo >> table-case-studies-original.txt
printf "%-32s  %7s  %3s  %20s  %11s \n" "Project" "LoC" "#Bugs" "#Warning suppressions" "#Annotations" >> table-case-studies-original.txt

export CHECKERFRAMEWORK=$1

# Prints one row of file table-case-studies-original.txt.
# Arguments:
#  * project name
#  * bugs fixed already (not in warning suppressions).
#    When counting the number of bugs detected, this script hard-codes those
#    bugs that have already been fixed.  Comments below give URLs to permit
#    the reader to verify that the hard-coded number is correct.
#  * lines of code to ignore, because scc does not yet support --exclude command-line option
#  * git repository
#  * branch name
printOneRow () {
  project=$1
  bugsfixed=$2
  locunchecked=$3
  gitrepo=$4
  gitbranch=$5

  reponame=${gitrepo##*/}
  echo "reponame=$reponame"
  dirbasename=$reponame-branch-$gitbranch
  dir=$scratch/$dirbasename
  echo "dir=$dir"

  if [ -d "$dir" ] ; then
      echo "$dir exists"
      git -C "$dir" pull
  else
      echo "$dir does not exist"
      (cd "$scratch" && git clone "$gitrepo" --branch "$gitbranch" "$dirbasename")
  fi

  # sourcedir contains the source code.  Using this avoids counting test code.
  if [ "$project" == "CF dataflow analysis" ] ; then
      sourcedir="$dir/dataflow/src/main/java"
  elif [ -d "$dir/src/main/java" ] ; then
      sourcedir="$dir/src/main/java"
  else
      sourcedir="$dir"
  fi

  # Compute lines of code.
  echo sourcedir="$sourcedir"
  locinsourcedir=$(cd "$sourcedir" && scc -ijava | grep 'Java' | awk 'BEGIN {ORS=""} {print $6}')
  echo locinsourcedir="$locinsourcedir"
  loc=$((locinsourcedir - locunchecked))

  # Typecheck with the Determinism Checker.
  if [ "$project" == "CF dataflow analysis" ] ; then
      typecheck_command="./gradlew clean :dataflow:checkDeterminism"
  elif [ "$project" == "Randoop" ] ; then
      typecheck_command="./gradlew clean assemble -PcfLocal -PuseCheckerFramework=true"
  elif [ -f "$dir/build.gradle" ] ; then
      typecheck_command="./gradlew clean assemble -PcfLocal"
  elif [ -f "$dir/pom.xml" ] ; then
      typecheck_command="mvn clean compile"
  else
      echo "no build file in $dir"
      exit 2
  fi    

  # Run DTC                                                        
  (cd "$dir" && $typecheck_command > typecheck-output.txt 2>&1)

  # Count the number of annotations.
  if [ "$reponame" == "checkstyle" ] ; then
      # I'm not sure whether this is a Checkstyle problem or a general Maven problem
      annos=$(grep -r -o -e '@\(NonDet\|OrderNonDet\|Det\|PolyDet\) ' "$sourcedir" | wc -l)
  else
      annos=$(grep '^org.checkerframework.checker.determinism.qual' "$dir/typecheck-output.txt" | awk '{sum+=$2} END {ORS=""; print sum+0}')
  fi
  echo annos="$annos"

  # Count the number of warning suppressions.
  suppressed=$(cd "$sourcedir" && "$CHECKERFRAMEWORK/checker/bin-devel/count-suppressions" determinism | grep -v "true positive" | awk '{sum+=$1} END {ORS=""; print sum+0}')
  echo suppressed="$suppressed"

  # Count the number of true positives, as indicated by comments in the source code.
  truepositive=$(cd "$sourcedir" && grep -r "true positive" "$sourcedir" | wc -l)
  echo truepositive="$truepositive"

  # Total bugs is those fixed and those remaining in the source code.
  bugs=$((bugsfixed + truepositive))

  # Print the line.
  printf "%-32s  %7s  %3s  %20s  %11s \n" "$project" "$loc" "$bugs" "$suppressed" "$annos" >> table-case-studies-original.txt
}


# Arguments are: project bugsfixed locunchecked gitrepo gitbranch


## Fixed bugs:
# 1: https://github.com/randoop/randoop/commit/c975a9f7
# 2: https://github.com/randoop/randoop/commit/330e3c56
# 1: https://github.com/randoop/randoop/commit/f212cc7e
# 1: https://github.com/randoop/randoop/commit/3d6cfb33
# 1: https://github.com/randoop/randoop/commit/97828027
# 1: https://github.com/randoop/randoop/commit/661a4970
# 1: https://github.com/randoop/randoop/commit/a460df97
# 5: https://github.com/randoop/randoop/commit/f8bdf992
# 1: https://github.com/randoop/randoop/commit/dff32159
printOneRow "Randoop" "13" "0" "https://github.com/t-rasmud/randoop" "determinism-redo"

## Fixed bugs:
# https://github.com/checkstyle/checkstyle/issues/8963
printOneRow "Checkstyle" "1" "0" "https://github.com/t-rasmud/checkstyle" "run-det-checker"

## Fixed bugs:
# 1: https://github.com/typetools/checker-framework/commit/601b6b5819a71194748c9a128befdfa01f37a8f8
# 1: https://github.com/typetools/checker-framework/commit/3057728a41b1dc1d53eaa2ffeb1bb1e9ec303e57
# 2: https://github.com/typetools/checker-framework/commit/8e7287b0bca3c7c2bbff42719895197e189eda89
# 3: https://github.com/typetools/checker-framework/commit/67702a13926eb3d17bde9cdbc7d4c66b7c570ea0
# 3: https://github.com/typetools/checker-framework/commit/bcba3cb7a508720766ee99ea19dd253f7c349b0a
# 26: https://github.com/typetools/checker-framework/commit/0ffe4902378112f0224d6134b64ff187f2ab95a7
# 1: https://github.com/typetools/checker-framework/commit/18f22f83efcb31791927adfc4f01d064b8eb8523
# 2: https://github.com/typetools/checker-framework/commit/24148f9140545e8b202b6f19961a5c4df25e936c
# 4: https://github.com/typetools/checker-framework/commit/0a0ea1021409ca8d2d5d7e7f57556ed45cd2472d
export CHECKERFRAMEWORK="$scratch/${$3##*/}-branch-$4"
printOneRow "CF dataflow analysis" "43" "0" "https://github.com/jwaataja/checker-framework" "dataflow-case-study"

export CHECKERFRAMEWORK=$1
printOneRow "bcel-util" "0" "0" "https://github.com/t-rasmud/bcel-util" "run-det-checker-polydet"
printOneRow "bibtex-clean" "0" "0" "https://github.com/t-rasmud/bibtex-clean" "run-det-checker"
printOneRow "html-pretty-print" "0" "0" "https://github.com/t-rasmud/html-pretty-print" "run-det-checker"
# Fixed bugs: https://github.com/plume-lib/icalavailable/commit/1a9ad3bd16b36ce3b6bedcbc2cab105e5ef69ea5
printOneRow "icalavailable" "1" "0" "https://github.com/t-rasmud/icalavailable" "run-det-checker"
printOneRow "lookup" "0" "0" "https://github.com/t-rasmud/lookup" "run-det-checker"
printOneRow "multi-version-control" "0" "0" "https://github.com/t-rasmud/multi-version-control" "run-det-checker"
printOneRow "options" "0" "0" "https://github.com/t-rasmud/options" "run-det-checker"
# Ignore WeakHasherMap.java and WeakIdentityHashMap.java in line counts
printOneRow "plume-util" "0" "1536" "https://github.com/t-rasmud/plume-util" "run-det-checker"
printOneRow "reflection-util" "0" "0" "https://github.com/t-rasmud/reflection-util" "run-det-checker-polydet"
printOneRow "require-javadoc" "0" "0" "https://github.com/t-rasmud/require-javadoc" "run-det-checker"
