#!/bin/bash

# Generate the file table-case-studies.txt.
if [ "x${JAVA_HOME}" = "x" ]; then
  has_java_home="no"
else    
  has_java_home="yes"
fi           

if [ "${has_java_home}" = "no" ]; then 
    echo "JAVA_HOME is not set to a JAVA 8"
    exit 1
fi
    
if [ "${has_java_home}" = "yes" ]; then
    java_version=$("${JAVA_HOME}"/bin/java -version 2>&1 | head -1 | cut -d'"' -f2 | sed '/^1\./s///' | cut -d'.' -f1)
    if [ "${java_version}" != 8 ]; then
        echo "JAVA_HOME is not set to a JAVA 8"
        exit 1
    fi
fi

set -o nounset
# set -o pipefail
# Display commands and their arguments as they are executed.
set -x
# set -v : Display shell input lines as they are read.

scratch=$1
mkdir -p "$scratch"

# Executes NonDex on benchmarks.
# Arguments:
#  * project name
#  * git repository
#  * branch name
runNonDex () {
  project=$1
  gitrepo=$2
  gitbranch=$3

  reponame=${gitrepo##*/}
  echo "reponame=$reponame"
  dirbasename=$reponame-branch-$gitbranch
  dir=$scratch/$dirbasename
  echo "dir=$dir"

  if [ -d "$dir" ] ; then
      echo "$dir exists"
      git -C "$dir" pull
  else
      echo "$dir does not exist"
      (cd "$scratch" && git clone "$gitrepo" --branch "$gitbranch" "$dirbasename")
  fi

  # Run NonDex.
  if [ -f "$dir/build.gradle" ] ; then
      nondex_command="./gradlew nondexTest"
  elif [ -f "$dir/pom.xml" ] ; then
      nondex_command="mvn nondex:nondex"
  else
      echo "no build file in $dir"
      exit 2
  fi    
  
  (cd "$dir" && $nondex_command > nondex-output.txt 2>&1)
}


# Arguments are: project gitrepo gitbranch

runNonDex "Checkstyle" "https://github.com/t-rasmud/checkstyle" "run-nondex"
runNonDex "CF Dataflow Analysis" "https://github.com/t-rasmud/checker-framework" "run-nondex"
runNonDex "bcel-util" "https://github.com/t-rasmud/bcel-util" "run-nondex"
runNonDex "bibtex-clean" "https://github.com/t-rasmud/bibtex-clean" "run-nondex"
runNonDex "html-pretty-print" "https://github.com/t-rasmud/html-pretty-print" "run-nondex"
runNonDex "icalavailable" "https://github.com/t-rasmud/icalavailable" "run-nondex"
runNonDex "lookup" "https://github.com/t-rasmud/lookup" "run-nondex"
runNonDex "multi-version-control" "https://github.com/t-rasmud/multi-version-control" "run-nondex"
runNonDex "options" "https://github.com/t-rasmud/options" "run-nondex"
runNonDex "plume-lib-util" "https://github.com/t-rasmud/plume-util" "run-nondex"
runNonDex "reflection-util" "https://github.com/t-rasmud/reflection-util" "run-nondex"
runNonDex "require-javadoc" "https://github.com/t-rasmud/require-javadoc" "run-nondex"
